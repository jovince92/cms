<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style>

        @media    only screen and (max-width: 600px) {
        
            .inner-body {
            
                width: 100% !important;
                
            }
                
                
            .footer {
                
                width: 100% !important;
                
            }
            
        }
            
            
        @media    only screen and (max-width: 500px) {
                
            .button {
                
                width: 100% !important;
                
            }
        
        }

        table{
            box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif, 'Apple Color Emoji', 'Segoe UI Emoji', 'Segoe UI Symbol'; position: relative; -premailer-cellpadding: 0; -premailer-cellspacing: 0; -premailer-width: 100%; background-color: #edf2f7; margin: 0; padding: 0; width: 100%;
        }
        td{
            box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif, 'Apple Color Emoji', 'Segoe UI Emoji', 'Segoe UI Symbol'; position: relative;
        }
        p{
            box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif, 'Apple Color Emoji', 'Segoe UI Emoji', 'Segoe UI Symbol'; position: relative; font-size: 16px; line-height: 1.5em; margin-top: 0; text-align: left;
        }
        th{
            min-width: 175px;
        }
        
    </style>
</head>
<body style="box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif, 'Apple Color Emoji', 'Segoe UI Emoji', 'Segoe UI Symbol'; position: relative; -webkit-text-size-adjust: none; background-color: #ffffff; color: #1a2a42; height: 100%; line-height: 1.4; margin: 0; padding: 0; width: 100% !important;">
    <div>
        <?php echo $body; ?>

    </div>
    
</body>
</html><?php /**PATH C:\xampp_php8.2\htdocs\cms\resources\views/emails/mail_request.blade.php ENDPATH**/ ?>